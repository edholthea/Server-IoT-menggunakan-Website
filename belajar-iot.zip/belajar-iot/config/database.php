<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "belajar_iot";

$conn = mysqli_connect($servername, $username, $password, $database);

?>
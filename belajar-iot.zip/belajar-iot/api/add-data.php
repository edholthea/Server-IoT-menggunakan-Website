<?php

include "../config/database.php";

$jenis_sensor = $_GET['jenis'];
$data_sensor = $_GET['data'];
$serial_number = $_GET['serial'];

$sql = "INSERT INTO sensor (jenis_sensor, data_sensor, serial_number)
        VALUES ('$jenis_sensor', '$data_sensor', '$serial_number')";

if(mysqli_query($conn, $sql)){
    echo "Data berhasil ditambahkan";
} else {
    echo "Data gagal ditambahkan";
}

?>